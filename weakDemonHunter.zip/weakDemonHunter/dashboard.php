<?php
 include '../component/sidebarManga.php'
?>
<style>
    body {
        background-color: #292929;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
</style>
<div
    style="margin: auto; width: 70%; solid #73AD21; padding: 10px;background-image: url(https://i2.wp.com/img.readmanga.cc/uploads/2021/10/Komik-Weak-Demon-Hunter.jpg?crop=100,100,100,60&resize=1263,351&quality=70); background-repeat: no-repeat; border-top: 0px solid #17337A; boxshadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <br>
    <br>
    <br>
    <br>
    <div class="d-flex">
        <div class="card" style="width: 10rem; background-color: transparent">
            <div style="text-align: center">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2021/10/Komik-Weak-Demon-Hunter.jpg"
                    width="200"
                    height="275"></div>
        </div>
        <div class="card mx-5" style="width: 48rem; background-color: #4a4a4a;">
            <div class="card-body">
                <h2 class="card-title" style="color: white;">Weak Demon Hunter</h2>
                <div style="color: white;">
                    Judul Alternatif: Teenage Exorcist, 弱鸡驱魔师, 급식 퇴마사, 급식퇴마사<br>
                    Status: Berjalan<br>
                    Pengarang: Jamu (자무)<br>
                    Ilustrator: Jamu (자무)<br>
                    Grafis: Shounen<br>
                    Tema: Action, School Life, Supernatural<br>
                    Jenis Komik: Manhwa</div>
            </div>
        </div>
    </div>
    <br>
    <h4 style="text-align: center; text-decoration: underline; color:white;">
        Komik Weak Demon Hunter Bahasa Indonesia
    </h4>
    <br>
    <table style="text-align: center">
        <tr>
            <td style="color: transparent">--------------------------------------------</td>
            <th style="color: white">Chapter Awal</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Semua Chapter</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Chapter Terbaru</th>
        </tr>
        <tr>
            <td style="color: transparent">-------------------------------------------</td>
            <td>
                <a href="../weakDemonHunter/eps1.php" class="btn btn-primary">Chapter 1</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../weakDemonHunter/eps1.php" class="btn btn-primary">All Chapter</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../weakDemonHunter/eps1.php" class="btn btn-primary">Chapter 168</a>
            </td>
        </tr>
    </table>
    <br>
    <div class="card mx-5" style="width: 58rem; background-color: #4a4a4a;">
        <div class="card-body">
            <h2 class="card-title" style="color: white;">Weak Demon Hunter</h2>
            <div style="color: white;">
            Manhwa Weak Demon Hunter yang dibuat oleh komikus bernama Jamu (자무) ini bercerita tentang Dengan kekuatan tangan kanannya, karakter utama, Woo Sukwang, yang selalu bertarung dengan baik dan selalu menjadi yang terbaik di setiap sekolah yang dia hadiri, juga legenda di antara teman-teman SMA-nya. Namun, keinginannya adalah menjalani kehidupan biasa seperti orang lain. Kemudian, dengan tidak sengaja, dia bertemu dengan kepala sekolah, Park Soo-ho, ternyata dia adalah exorcist, dan dia berkata akan mengajarinya cara mengendalikan tangan kanan nya. Dengan syarat dia harus bergabung dengan klub exorcist.
            </div>
        </div>
    </aside>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</body>
</html>