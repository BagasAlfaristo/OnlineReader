<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/2/15244f64a312fb41ce333d7e58d797c6/7cvnFnaLBhF22l3TvrVLi9agjXaJUdy7pS6l5OKb.jpg'>
            <br>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/2/15244f64a312fb41ce333d7e58d797c6/IRrKWYTmFlfPDKhiNEQGhlhUjiHPiCyqYXs3TfVa.jpg'>
    </div>
    <br>
    <a href="../weakDemonHunter/eps2.php" class="btn btn-primary">Episode 3</a>
    <br>
</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>