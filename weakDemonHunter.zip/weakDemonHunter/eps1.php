<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/1/4308dcf181a341086a56f10ca4c4333c/rG6zwbv936noHQieRRyWEGo6FSEd8WRedFSflyx7.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/1/4308dcf181a341086a56f10ca4c4333c/ZgbVvAQyL5Ts0C7A8kYHMejVykSQGQoRZzoQnYVT.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/1/4308dcf181a341086a56f10ca4c4333c/2rIgLu5fa2kstOLrsz5t2ZEdTn95cGhE1u6kPAMU.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/1/4308dcf181a341086a56f10ca4c4333c/hUGCheKIRxfM1fk4TqTmXgsGE0LK2Jr04bcGPMG8.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/1/4308dcf181a341086a56f10ca4c4333c/ImukJKlJXqkiLjoaq4uuCmRVLt3A24kZUp5b6z8I.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/23225732/1/4308dcf181a341086a56f10ca4c4333c/1HgTAi0sH763XZX6wciEEcUddNUxC3QiJKswTbT4.jpg'>    
            
    </div>
    <br>
    <a href="../weakDemonHunter/eps2.php" class="btn btn-primary">Episode 2</a>
    <br>
</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>