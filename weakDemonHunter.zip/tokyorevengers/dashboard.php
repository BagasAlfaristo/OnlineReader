<?php
 include '../component/sidebarManga.php'
?>
<style>
    body {
        background-color: #292929;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
</style>
<div
    style="margin: auto; width: 70%; solid #73AD21; padding: 10px;background-image: url(https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg?crop=100,100,100,60&resize=1263,351&quality=70); background-repeat: no-repeat; border-top: 0px solid #17337A; boxshadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <br>
    <br>
    <br>
    <br>
    <div class="d-flex">
        <div class="card" style="width: 10rem; background-color: transparent">
            <div style="text-align: center">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="200"
                    height="275"></div>
        </div>
        <div class="card mx-5" style="width: 48rem; background-color: #4a4a4a;">
            <div class="card-body">
                <h2 class="card-title" style="color: white;">Tokyo卍Revengers</h2>
                <div style="color: white;">
                    Judul Alternatif: Tokyo Manji Revengers, Tokyo Revengers, Tokyo 卍 Revengers, Токийские мстители, 东京卍复仇者, 東京卍リベンジャーズ, 東京卍復仇者<br>
                    Status: Berjalan<br>
                    Pengarang: Wakui Ken<br>
                    Ilustrator: Wakui Ken<br>
                    Grafis: Shounen<br>
                    Tema: Delinquents, Supernatural, Time Travel<br>
                    Jenis Komik: Manga</div>
            </div>
        </div>
    </div>
    <br>
    <h4 style="text-align: center; text-decoration: underline; color:white;">
        Komik Tokyo卍Revengers Bahasa Indonesia
    </h4>
    <br>
    <table style="text-align: center">
        <tr>
            <td style="color: transparent">--------------------------------------------</td>
            <th style="color: white">Chapter Awal</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Semua Chapter</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Chapter Terbaru</th>
        </tr>
        <tr>
            <td style="color: transparent">-------------------------------------------</td>
            <td>
                <a href="../tokyorevengers/eps1.php" class="btn btn-primary">Chapter 1</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../tokyorevengers/eps1.php" class="btn btn-primary">All Chapter</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../tokyorevengers/eps1.php" class="btn btn-primary">Chapter 168</a>
            </td>
        </tr>
    </table>
    <br>
    <div class="card mx-5" style="width: 58rem; background-color: #4a4a4a;">
        <div class="card-body">
            <h2 class="card-title" style="color: white;">Tokyo卍Revengers</h2>
            <div style="color: white;">
            Manga Tokyo卍Revengers yang dibuat oleh komikus bernama Wakui Ken ini bercerita tentang Takemichi adalah gadis pengangguran berusia 26 tahun yang mengetahui bahwa gadis yang dia kencani di sekolah menengah, satu-satunya gadis yang pernah dia kencani, telah meninggal. Kemudian, setelah kecelakaan dia menemukan dirinya dalam lompatan waktu kembali ke tahun-tahun sekolah menengahnya. Dia bersumpah untuk mengubah masa depan dan menyelamatkan gadis itu, dan untuk melakukan itu dia bertujuan untuk naik ke puncak geng nakal paling brutal di wilayah Kantou.
            </div>
        </div>
    </aside>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</body>
</html>