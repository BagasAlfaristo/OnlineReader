<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/dgXZseCMqe002.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/5qvGFCpcKU003.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/GNSc2cU9BN004.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/1v3s8xOH3o005.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/Wu1EHrs70y006.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/JLMAji47FY007.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/5K8PLNralk008.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/970151/1/cSvnBCLGfsgrWmU/sVZ922ghzP009.jpg'>

    </div>

</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>