<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/61187912/1/f3370c61e8582169f94cdc56f65ca422/FBLDMzLQEQfLJ3ggeUp8U81rOiINE2kBqxnnh6Lf.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/61187912/1/f3370c61e8582169f94cdc56f65ca422/kwEoUWgbtcM3VMBQ4FjZKDFafUQEkwLhLKoMPx00.jpg'>
    </div>
    <br>
    <a href="../genshinimpact/eps2.php" class="btn btn-primary">Episode 2</a>
    <br>
</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>