<?php
 include '../component/sidebarManga.php'
?>
<style>
    body {
        background-color: #292929;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
</style>
<div
    style="margin: auto; width: 70%; solid #73AD21; padding: 10px;background-image: url(https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg?crop=100,100,100,60&resize=1263,351&quality=70); background-repeat: no-repeat; border-top: 0px solid #17337A; boxshadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <br>
    <br>
    <br>
    <br>
    <div class="d-flex">
        <div class="card" style="width: 10rem; background-color: transparent">
            <div style="text-align: center">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                    width="200"
                    height="275"></div>
        </div>
        <div class="card mx-5" style="width: 48rem; background-color: #4a4a4a;">
            <div class="card-body">
                <h2 class="card-title" style="color: white;">Solo Leveling</h2>
                <div style="color: white;">
                    Judul Alternatif: Aku Level Up Sendiri, I Alone Level Up, Solo Levelling,
                    俺だけレベルアップな件, 나 혼자만 레벨업<br>
                    Status: Berjalan<br>
                    Pengarang: Chugong 추공<br>
                    Ilustrator: Jang Sung-Rak (REDICE Studio)<br>
                    Grafis: Shounen<br>
                    Tema: Magic, Demons<br>
                    Jenis Komik: Manhwa</div>
            </div>
        </div>
    </div>
    <br>
    <h4 style="text-align: center; text-decoration: underline; color:white;">
        Komik Solo Leveling Bahasa Indonesia
    </h4>
    <br>
    <table style="text-align: center">
        <tr>
            <td style="color: transparent">--------------------------------------------</td>
            <th style="color: white">Chapter Awal</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Semua Chapter</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Chapter Terbaru</th>
        </tr>
        <tr>
            <td style="color: transparent">-------------------------------------------</td>
            <td>
                <a href="../soloLeveling/eps1.php" class="btn btn-primary">Chapter 1</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../soloLeveling/eps1.php" class="btn btn-primary">All Chapter</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../soloLeveling/eps1.php" class="btn btn-primary">Chapter 168</a>
            </td>
        </tr>
    </table>
    <br>
    <div class="card mx-5" style="width: 58rem; background-color: #4a4a4a;">
        <div class="card-body">
            <h2 class="card-title" style="color: white;">Solo Leveling</h2>
            <div style="color: white;">
                Sinopsis Manhwa Solo Leveling Bahasa Indonesia Manhwa Solo Leveling yang dibuat
                oleh komikus bernama Chugong 추공 ini bercerita tentang 10 tahun yang lalu,
                setelah "Gerbang" yang menghubungkan dunia nyata dengan dunia monster terbuka,
                beberapa orang biasa, setiap hari menerima kekuatan untuk berburu monster di
                dalam Gerbang. Mereka dikenal sebagai "Pemburu". Namun, tidak semua Pemburu
                kuat. Nama saya Sung Jin-Woo, seorang Pemburu peringkat-E. Saya seseorang yang
                harus mempertaruhkan nyawanya di ruang bawah tanah paling rendah, "Terlemah di
                Dunia". Tidak memiliki keterampilan apa pun untuk ditampilkan, saya hampir tidak
                mendapatkan uang yang dibutuhkan dengan bertarung di ruang bawah tanah berlevel
                rendah…setidaknya sampai saya menemukan ruang bawah tanah tersembunyi dengan
                kesulitan tersulit dalam ruang bawah tanah peringkat-D! Pada akhirnya, saat aku
                menerima kematian, tiba-tiba aku menerima kekuatan aneh, log pencarian yang
                hanya bisa kulihat, rahasia untuk naik level yang hanya aku yang tahu! Jika saya
                berlatih sesuai dengan pencarian saya dan monster yang diburu, level saya akan
                naik. Berubah dari Hunter terlemah menjadi Hunter S-rank terkuat!
            </div>
        </div>
    </aside>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</body>
</html>