<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/eG6WiHd9Woz1fyC001.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/SXYoWy6wb5OCEvi002.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/aVqOgr24ws0sY9H003.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/v8N9G4fFmnBvAZy004.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/Lax2FfjQzlINuye005.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/U6DdCAIJVdmN5F8006.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/742688/1/SCH74srmqjNMvJk/BgfXZgtuqBZYsUA007.jpg'>
    </div>

</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>