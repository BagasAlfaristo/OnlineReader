<?php
 include '../component/sidebar.php'
 ?>
include

<style>
    body {
        background-color: #292929;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
    .card {
        background-color: #292929;
        width: 11rem;
    }
    .card-title {
        color: white;
        text-align: center;
    }
    .btn {
        text-align: center;
        color: white;
    }
    .text {
        color: white;
    }
    div.scrollmenu {
        background-color: transparent;
        overflow: auto;
        white-space: nowrap;
    }
    div.scrollmenu a {
        display: inline-block;
        color: white;
        text-align: center;
        padding: 0;
        text-decoration: none;
    }
    div.scrollmenu a:hover {
        background-color: #777;
    }
</style>
<div
    class="container p-6 m-12 h-10"
    style="background-color: #292929; border-top: 20px solid #292929; boxshadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <table>
        <tr>
            <td>
                <h4 class="text">Manga
                </h4>
            </td>
            <td style="color: transparent">-----------------------------------------------------------------------------------------------------------------------------------------------------</td>
            <td style="text-align: right">
                <a href="./allManga.php" class="btn btn-primary">See All</a>
            </td>
        </tr>
    </table>
    <hr>
    <div class="d-flex">
        <div class="card">
            <a href="../tokyorevengers/dashboard.php">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="160"
                    height="200">
                <div class="card-body">
                    <h5 class="card-title">Tokyo卍Revengers</h5>
                </div>
            </div>
        </a>
        <div class="card mx-4">
            <a href="../tokyorevengers/dashboard.php">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="160"
                    height="200">
                <div class="card-body">
                    <h5 class="card-title">Tokyo卍Revengers</h5>
                </div>
            </div>
        </a>
        <div class="card">
            <a href="../tokyorevengers/dashboard.php">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="160"
                    height="200">
                <div class="card-body">
                    <h5 class="card-title">Tokyo卍Revengers</h5>
                </div>
            </div>
        </a>
        <div class="card mx-4">
            <a href="../tokyorevengers/dashboard.php">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="160"
                    height="200">
                <div class="card-body">
                    <h5 class="card-title">Tokyo卍Revengers</h5>
                </div>
            </a>
        </div>
        <div class="card">
            <a href="../tokyorevengers/dashboard.php">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="160"
                    height="200">
                <div class="card-body">
                    <h5 class="card-title">Tokyo卍Revengers</h5>
                </div>
            </div>
        </a>
        <div class="card mx-4">
            <a href="../tokyorevengers/dashboard.php">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-TokyoRevengers.jpg"
                    width="160"
                    height="200">
                <div class="card-body">
                    <h5 class="card-title">Tokyo卍Revengers</h5>
                </div>
            </div>
        </a>
    </div>
    <br>
    <table>
        <tr>
            <td>
                <h4 class="text">Manhua
                </h4>
            </td>
            <td style="color: transparent">---------------------------------------------------------------------------------------------------------------------------------------------------</td>
            <td style="text-align: right">
                <a href="./allManhua.php" class="btn btn-primary">See All</a>
            </td>
        </tr>
    </table>
    <hr>
    <div class="scrollmenu">
        <div class="d-flex">
            <div class="card">
                <a href="../yuanzun/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Yuan-Zun.png"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Yuan Zun</h5>
                    </div>
                </div>
            </a>
            <div class="card mx-4">
                <a href="../yuanzun/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Yuan-Zun.png"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Yuan Zun</h5>
                    </div>
                </div>
            </a>
            <div class="card">
                <a href="../yuanzun/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Yuan-Zun.png"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Yuan Zun</h5>
                    </div>
                </div>
            </a>
            <div class="card mx-4">
                <a href="../yuanzun/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Yuan-Zun.png"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Yuan Zun</h5>
                    </div>
                </a>
            </div>
            <div class="card">
                <a href="../yuanzun/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Yuan-Zun.png"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Yuan Zun</h5>
                    </div>
                </div>
            </a>
            <div class="card mx-4">
                <a href="../yuanzun/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Yuan-Zun.png"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Yuan Zun</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
    <br>
    <table>
        <tr>
            <td>
                <h4 class="text">Manhwa
                </h4>
            </td>
            <td style="color: transparent">--------------------------------------------------------------------------------------------------------------------------------------------------</td>
            <td style="text-align: right">
                <a href="./allManhwa.php" class="btn btn-primary">See All</a>
            </td>
        </tr>
    </table>
    <hr>
    <div class="scrollmenu">
        <div class="d-flex">
            <div class="card">
                <a href="../soloLeveling/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Solo Leveling</h5>
                    </div>
                </div>
            </a>
            <div class="card mx-4">
                <a href="../soloLeveling/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Solo Leveling</h5>
                    </div>
                </div>
            </a>
            <div class="card">
                <a href="../soloLeveling/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Solo Leveling</h5>
                    </div>
                </div>
            </a>
            <div class="card mx-4">
                <a href="../soloLeveling/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Solo Leveling</h5>
                    </div>
                </a>
            </div>
            <div class="card">
                <a href="../soloLeveling/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Solo Leveling</h5>
                    </div>
                </div>
            </a>
            <div class="card mx-4">
                <a href="../soloLeveling/dashboard.php">
                    <img
                        class="card-imgtop"
                        src="https://i2.wp.com/img.readmanga.cc/uploads/2020/12/Komik-Solo-Leveling.jpeg"
                        width="160"
                        height="200">
                    <div class="card-body">
                        <h5 class="card-title">Solo Leveling</h5>
                    </div>
                </div>
            </a>
        </div>
    </div>
</aside>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>