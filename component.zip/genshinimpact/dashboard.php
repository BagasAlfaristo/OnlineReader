<?php
 include '../component/sidebarManga.php'
?>
<style>
    body {
        background-color: #292929;
        background-attachment: fixed;
        background-repeat: no-repeat;
    }
</style>
<div
    style="margin: auto; width: 70%; solid #73AD21; padding: 10px;background-image: url(https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Genshin-Impact-4-koma.png?crop=100,100,100,60&resize=1263,351&quality=70); background-repeat: no-repeat; border-top: 0px solid #17337A; boxshadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <br>
    <br>
    <br>
    <br>
    <div class="d-flex">
        <div class="card" style="width: 10rem; background-color: transparent">
            <div style="text-align: center">
                <img
                    class="card-imgtop"
                    src="https://i2.wp.com/img.readmanga.cc/uploads/2021/01/Komik-Genshin-Impact-4-koma.png"
                    width="200"
                    height="275"></div>
        </div>
        <div class="card mx-5" style="width: 48rem; background-color: #4a4a4a;">
            <div class="card-body">
                <h2 class="card-title" style="color: white;">Genshin Impact 4-koma</h2>
                <div style="color: white;">
                    Judul Alternatif: 《原神》四格漫画, Genshin Impact 4-Panel Comics<br>
                    Status: Berjalan<br>
                    Pengarang: miHoYo<br>
                    Ilustrator: miHoYo<br>
                    Grafis: -<br>
                    Tema: Magic, Video Games<br>
                    Jenis Komik: Manhua</div>
            </div>
        </div>
    </div>
    <br>
    <h4 style="text-align: center; text-decoration: underline; color:white;">
        Komik Genshin Impact 4-koma Bahasa Indonesia
    </h4>
    <br>
    <table style="text-align: center">
        <tr>
            <td style="color: transparent">--------------------------------------------</td>
            <th style="color: white">Chapter Awal</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Semua Chapter</th>
            <td style="color: transparent">---------</td>
            <th style="color: white">Chapter Terbaru</th>
        </tr>
        <tr>
            <td style="color: transparent">-------------------------------------------</td>
            <td>
                <a href="../genshinimpact/eps1.php" class="btn btn-primary">Chapter 1</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../genshinimpact/eps1.php" class="btn btn-primary">All Chapter</a>
            </td>
            <td style="color: transparent">---------</td>
            <td>
                <a href="../genshinimpact/eps1.php" class="btn btn-primary">Chapter 168</a>
            </td>
        </tr>
    </table>
    <br>
    <div class="card mx-5" style="width: 58rem; background-color: #4a4a4a;">
        <div class="card-body">
            <h2 class="card-title" style="color: white;">Genshin Impact 4-koma</h2>
            <div style="color: white;">
            Manhua Genshin Impact 4-koma yang dibuat oleh komikus bernama miHoYo ini bercerita tentang Komik 4-koma resmi untuk game pemenang penghargaan, Genshin Impact.
            </div>
        </div>
    </aside>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
</body>
</html>