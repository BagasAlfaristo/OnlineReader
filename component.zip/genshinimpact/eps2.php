<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/61187912/2/e199c250b85b51d42ca984530074163b/WQpVPfzAAln05wW2SKNYqcBMRd9NXbfayMtKEnRX.jpg'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/61187912/2/e199c250b85b51d42ca984530074163b/spLbWEqk6g2MF7ivJ6a7MAbwsZNGaxbVShBGOSki.jpg'>
    </div>
    <br>
    <a href="../genshinimpact/eps2.php" class="btn btn-primary">Episode 3</a>
    <br>
</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>