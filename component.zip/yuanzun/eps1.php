<?php
include '../component/sidebarRead.php'
?>
<br>
<br>
<br>
<div style="text-align: center;">
    <div>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/OjMyVvV7SwZsZ67001.webp'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/reCrBHXcbMLFOUK002.webp'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/HvaRR389ybgZUQT003.webp'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/eW3oNpX3yZLlw5G004.webp'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/0e8m9chI43fj7dr005.webp'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/ciiRahzrIMpd9tG006.webp'>
        <img
            src='https://img.statically.io/img/bacakomik/cok.masterimg.xyz/data/112221/1/zZjmtwSOORNUV5e/3OnLCZyuxDWAG8D007.webp'>
    </div>

</div>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-
MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
</body>
</html>